# Aurora Roadmap

## Canonical status

**Current acceptance exceptions (2026-10-09):** the latest live NVIDIA-only acceptance runs (37814164201 and 37813096077) failed with HTTP 403 during real inference. This is not a green live gate. The five autonomy controllers from PR #177 have deterministic unit coverage, but runtime integration is only partial; the mission manager is now wired into the canonical runtime on the current remediation branch. Do not mark these items complete until the corresponding live/E2E proofs pass.


**Canonical engineering branch: `main`**

Authoritative status:
- `docs/AURORA_CONSOLIDATION_MATRIX.md`
- Issue #50 (CLOSED)
- consolidation evidence branch: `runtime/consolidation-gate`
- CI 1291–1296: SUCCESS
- CI 1305: SUCCESS — research discovery E2E
- CI 1306: SUCCESS — canonical main after merge
- CI 1392: SUCCESS — Production Observability V1
- CI 1398/1399: SUCCESS — Recovery Drills V1
- CI 1414: SUCCESS — Controlled Live Authorization V1 on canonical main

The repository is no longer tracking historical increments as future work. The sections below describe what is already integrated and what remains genuinely required.

## Phase 0 — Foundation / Governance — INTEGRATED

Repository architecture, governance, security policy, schemas, CI and operational records are integrated.

## Phase 1 — Autonomous Capability Acquisition — INTEGRATED

Integrated:
- capability registry and broker;
- governed capability discovery and persistent acquisition;
- APT/PyPI acquisition;
- artifact verification/provenance;
- dependency closure;
- transactional state, staging, recovery and reconciliation;
- tool artifact injection.

Remaining non-queue hardening:
- additional acquisition source families where required;

## Phase 2 — Runtime Safety / Persistence / Recovery — INTEGRATED

Integrated:
- sandboxed execution;
- deterministic isolated workspaces;
- application network gateway/proxy/dataplane;
- durable task/event state;
- leases, crash recovery and reconciliation;
- bounded concurrency and shared-resource locking.

Production verification for the frozen queue is complete:
- production observability — VERIFIED;
- controlled recovery drills — VERIFIED;
- OS/network enforcement — VERIFIED.

## Phase 3 — Director / Organization / Mission Runtime — INTEGRATED

Integrated:
- provider-neutral Director planning/review;
- durable TaskEngine;
- 24/7 DirectorRuntime and daemon;
- shared mission memory/inbox;
- bounded adaptive review/replan;
- organization/departments;
- specialist team formation and adaptation.

Loop safety is established by bounded per-mission review/cycle budgets and durable restart state.

## Phase 8 — Adaptive Agent Intelligence — CLOSED

Integrated and verified:
- specialist skill evaluation;
- durable skill learning;
- model performance history;
- dynamic model routing;
- evidence-backed skill evolution;
- approval/promotion;
- validation, regression and rollback;
- adaptive specialist-agent selection.

## Phase 9 — Knowledge & Research Intelligence — INTEGRATED

Integrated:
1. research domain and durable evidence;
2. redirect-safe provenance;
3. deterministic source parsing and claim extraction;
4. independent verification and contradiction handling;
5. trusted knowledge artifacts and citation graph;
6. Director/TaskEngine research delegation;
7. trust-gated research → learning;
8. verified execution evidence affecting later ModelRouter decisions.

The existing `HttpSearchProvider` is now injected by the normal runtime factory when `AURORA_RESEARCH_DISCOVERY_ENDPOINT` is configured. `DirectorRuntime.acquire_specialist()` reaches this path through `SkillDiscoveryService`, which delegates source discovery to `ResearchService.discover()`. CI 1305 provides the controlled HTTP end-to-end proof and CI 1306 verifies the merged canonical `main`.

The adaptive routing proof used controlled/test providers. Live NVIDIA and Gemini verification remain separate gates.

## Cross-cutting Director Decision Intelligence — INTEGRATED

Integrated and verified:
- decision outcome/evidence sufficiency;
- durable performance aggregation;
- explicit comparative alternatives;
- independent comparative evidence;
- cross-decision replication;
- promoted empirical knowledge;
- governed policy proposals;
- validation and canary lifecycle;
- shadow canary evaluation/rollback;
- active policy registry;
- immutable typed active policy contracts.

## Current live-provider verification — NOT CLOSED

Historical live-provider gates are retained as evidence of earlier runtime states; they do not certify the current NVIDIA-only free-model topology. The current live NVIDIA inference gate failed with HTTP 403 on runs 37814164201 and 37813096077. The current free-model resilience gate remains pending until real NVIDIA inference succeeds and reserve/fail-closed behavior is proven. Do not label the current provider topology LIVE VERIFIED based on historical Gemini-to-NVIDIA runs.

Current evidence:
- ordinary CI on main: run 37884952749 SUCCESS;
- current NVIDIA live inference: BLOCKED, HTTP 403;
- current multi-provider/free-model resilience: LIVE PENDING;
- local WSL/dashboard conversation: NOT VERIFIED by GitHub CI.

## Frozen historical production-readiness queue — COMPLETE AT ITS VERIFIED BASELINE

Blocks 1–7 were verified on their respective historical canonical commits. That historical closure is not evidence that the current provider configuration is live-ready. The current NVIDIA-only live gate remains blocked as stated above. The historical queue was:
1. LIVE-RESEARCH-DISCOVERY
2. OS-NETWORK-ENFORCEMENT
3. LIVE-NVIDIA
4. LIVE-GEMINI
5. PRODUCTION-OBSERVABILITY
6. RECOVERY-DRILLS
7. CONTROLLED-LIVE-AUTHORIZATION

The queue is closed. Block 7 establishes the explicit authorization boundary; it does not activate live execution automatically. Aurora remains fail-closed unless a human operator supplies a valid authorization record matching the verified canonical commit and prerequisites.

## Increment policy

**Increment 11 — Director Handoff / Failover: COMPLETE. Gates 1–8 are COMPLETE and canonically verified on main.**


## Increment 12 — Director Provider Failover / Replacement — COMPLETE / LIVE VERIFIED

**Scope:** provider-level replacement only. Increment 11 remains COMPLETE and is not reopened.

Target lifecycle:

    active Director provider -> provider failure -> eligible alternative -> replacement active -> same Aurora state -> continuation

Canonical implementation:
- PR #121 merged to main as `69edf62465e6aebea6a064d23b06efc3df38058d`;
- canonical post-merge CI #2104 green (`test` + `e2e-network`);
- durable provider failure/failover evidence store;
- provider-neutral failover controller;
- operator-configurable fallback order;
- Gemini failure classification for failoverable versus non-transient client errors;
- runtime integration for planning, review and durable conversation;
- successful replacement persisted for restart continuity;
- deterministic provider, mission, conversation, fail-closed and restart-persistence acceptance tests green;
- automatic switchback to a previously failed primary provider is not performed.

Acceptance plan:
- docs/operations/INCREMENT_12_DIRECTOR_PROVIDER_FAILOVER_CONTRACT.md
- docs/operations/INCREMENT_12_DIRECTOR_PROVIDER_FAILOVER_ACCEPTANCE_PLAN.md

Deterministic proof: VERIFIED on canonical main.

External live proof:
- workflow: `.github/workflows/live-director-provider-failover.yml`;
- test: `tests/e2e/test_live_director_provider_failover.py`;
- environment: `director-provider-failover-live`;
- live run: GitHub Actions run `37179243481` (job `111368251139`);
- primary: real Gemini `gemini-3.7-flash`;
- replacement: real NVIDIA provider using the NVIDIA served model supplied to the gate;
- result: SUCCESS — real primary response, controlled Gemini failure, real NVIDIA replacement response, provider transition evidence recorded;
- credential leakage: none observed in the gate output.

**Increment 12 historical acceptance: CLOSED / VERIFIED for the Gemini-to-NVIDIA topology tested in run 37179243481. This does not verify the current NVIDIA-only runtime.**

No live authorization is activated by the gate.

Scope remains isolated to safe replacement and recovery of an active Director during an in-progress durable mission. Unrelated dashboard, model, provider, research, and frozen production-readiness work remains out of scope.



## Universal Work / Cowork Architecture — IMPLEMENTED AND VERIFIED

The Universal Workbench & Integration Plane is implemented on canonical `main` and has completed final Director-led end-to-end acceptance. The acceptance record is maintained in `docs/architecture/AURORA_UNIVERSAL_WORKBENCH_ARCHITECTURE.md`.

The Workbench provides the governed shared capability plane for local files/computer, artifacts/documents/images, browser, GitHub, external connectors, MCP, research, multimodal processing, code/tool execution, capability discovery/acquisition/fallback and durable evidence/audit.

It does not reopen Increment 11, Increment 12 or the frozen production-readiness queue.

## Increment 13 — Free-Model Inference Resilience — IMPLEMENTED / AUTOMATED VERIFIED / LIVE PENDING

PRs already integrated on `main`:

- **PR #149** — Critical Decision Model Ensemble.
- **PR #150** — Multi-Agent Adversarial Review.
- **PR #151** — Provider Health / Availability, discovery, dynamic reserve pool, governed catalog refresh and multi-provider fail-closed resilience. Optional paid adapters remain outside the canonical free-only runtime.

The canonical CI for PR #151 passed the full unit/integration suite and the E2E suite.

Implemented boundary:

    free-model policy
        -> provider/model health
        -> health-aware ModelRouter
        -> NVIDIA catalog discovery
        -> governed staged candidates
        -> dynamic free reserve pool
        -> existing Director provider failover
        -> critical-decision ensemble
        -> adversarial specialist review

The remaining acceptance step is the dedicated LIVE gate against the real free Gemini tier and the current NVIDIA Free Endpoint catalog. The implementation dynamically discovers served models and joins them with the official NVIDIA catalog rather than using a fixed model allowlist. Paid-provider credentials are neither required nor part of the canonical runtime.

Acceptance artifact:

`docs/operations/LIVE_MULTI_PROVIDER_RESILIENCE.md`

**LIVE status:** PENDING execution of the dedicated gate.
