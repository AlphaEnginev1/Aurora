#!/usr/bin/env python3
"""Prueba cada modelo de config/inference-policy.json con tu NVIDIA_API_KEY.

Uso:
    NVIDIA_API_KEY=... python3 scripts/probe-nvidia-models.py            # solo informa
    NVIDIA_API_KEY=... python3 scripts/probe-nvidia-models.py --apply    # habilita solo los que responden 200

Solo usa la biblioteca estandar. Hace una llamada minima (max_tokens=8) por modelo.
Un 403 indica que la clave no tiene acceso a ese modelo; no lo habilites.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

POLICY = Path(__file__).resolve().parents[1] / "config" / "inference-policy.json"


def probe(base_url: str, key: str, model_id: str, timeout: float) -> tuple[int | None, float, str]:
    body = json.dumps(
        {
            "model": model_id,
            "messages": [{"role": "user", "content": "Responde solo: ok"}],
            "max_tokens": 8,
            "temperature": 0,
        }
    ).encode("utf-8")
    request = urllib.request.Request(
        base_url.rstrip("/") + "/chat/completions",
        data=body,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        method="POST",
    )
    started = time.monotonic()
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            response.read()
            return response.status, time.monotonic() - started, "ok"
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:120].replace("\n", " ")
        return exc.code, time.monotonic() - started, detail
    except Exception as exc:  # red, DNS, timeout
        return None, time.monotonic() - started, f"{type(exc).__name__}: {exc}"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--apply", action="store_true", help="escribe enabled=true solo para los modelos con HTTP 200")
    parser.add_argument("--timeout", type=float, default=30.0)
    args = parser.parse_args()

    key = os.getenv("NVIDIA_API_KEY", "").strip()
    if not key:
        print("Falta NVIDIA_API_KEY en el entorno.", file=sys.stderr)
        return 2

    policy = json.loads(POLICY.read_text(encoding="utf-8"))
    base_url = policy["providers"]["nvidia_api"]["base_url"]
    working: list[str] = []
    print(f"{'modelo':45} {'HTTP':>5} {'seg':>6}  detalle")
    for model in policy["models"]:
        status, seconds, detail = probe(base_url, key, model["id"], args.timeout)
        print(f"{model['id']:45} {str(status):>5} {seconds:6.1f}  {detail if status != 200 else ''}")
        if status == 200:
            working.append(model["id"])

    print(f"\nResponden 200: {len(working)} de {len(policy['models'])}")
    if len(working) < 2:
        print("AVISO: hay menos de 2 modelos operativos; la conmutacion por fallo no tendra alternativas.")
    if args.apply:
        if not working:
            print("No se modifica la politica: ningun modelo respondio 200.", file=sys.stderr)
            return 1
        for model in policy["models"]:
            model["enabled"] = model["id"] in working
        POLICY.write_text(json.dumps(policy, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print("Politica actualizada:", ", ".join(working))
    return 0 if working else 1


if __name__ == "__main__":
    raise SystemExit(main())
