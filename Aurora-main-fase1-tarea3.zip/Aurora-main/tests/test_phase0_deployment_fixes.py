"""Regresiones de la Fase 0: preflight, politica de modelos y unidades systemd."""
import json
import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).parents[1]
DEPLOY = ROOT / "deploy"


def test_preflight_has_no_escaped_shell_variables():
    script = (DEPLOY / "aurora-preflight.sh").read_text(encoding="utf-8")
    assert "\\${" not in script


@pytest.mark.skipif(shutil.which("bash") is None, reason="bash required")
def test_preflight_script_is_valid_bash():
    result = subprocess.run(["bash", "-n", str(DEPLOY / "aurora-preflight.sh")], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr


@pytest.mark.skipif(shutil.which("bash") is None, reason="bash required")
def test_preflight_expands_python_path_instead_of_printing_literal_variable(tmp_path):
    (tmp_path / "deploy").mkdir()
    shutil.copy(DEPLOY / "aurora-preflight.sh", tmp_path / "deploy" / "aurora-preflight.sh")
    result = subprocess.run(
        ["bash", str(tmp_path / "deploy" / "aurora-preflight.sh")], capture_output=True, text=True
    )
    assert result.returncode != 0
    assert "${" not in result.stderr
    assert str(tmp_path / ".venv" / "bin" / "python") in result.stderr


def test_preflight_supports_version_file_without_git():
    script = (DEPLOY / "aurora-preflight.sh").read_text(encoding="utf-8")
    assert "${ROOT}/VERSION" in script


def test_inference_policy_enables_only_free_allowlisted_models():
    policy = json.loads((ROOT / "config" / "inference-policy.json").read_text(encoding="utf-8"))
    free = json.loads((ROOT / "config" / "free-model-policy.json").read_text(encoding="utf-8"))
    allowed = {
        model_id
        for model_id, record in free["providers"]["nvidia_api"]["models"].items()
        if record.get("tier") == "free"
    }
    enabled = [m for m in policy["models"] if m.get("enabled") is True]
    assert len(enabled) >= 2
    for model in enabled:
        assert model["pricing_tier"] == "free"
        assert model["id"] in allowed


def test_egress_proxy_has_its_own_service_and_runtime_orders_after_it():
    proxy = (DEPLOY / "aurora-egress-proxy.service").read_text(encoding="utf-8")
    runtime = (DEPLOY / "aurora.service").read_text(encoding="utf-8")
    assert "aurora.autonomy.egress_proxy_daemon" in proxy
    assert "Restart=always" in proxy
    assert "EnvironmentFile=/etc/aurora/aurora.env" in proxy
    assert "aurora-egress-proxy.service" in runtime


def test_dev_preflight_is_not_confused_with_production_preflight():
    assert (ROOT / "scripts" / "dev-preflight.sh").is_file()
    assert not (ROOT / "scripts" / "aurora-preflight.sh").exists()
