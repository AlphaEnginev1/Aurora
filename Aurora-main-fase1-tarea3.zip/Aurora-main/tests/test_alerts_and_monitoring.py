"""Tarea 3 (Fase 1): alertas, chequeos de salud y monitor externo."""
import json
import socket
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from threading import Thread
from types import SimpleNamespace

import pytest

from aurora.alerts import (
    AlertManager,
    AlertMessage,
    HttpPoster,
    TelegramChannel,
    WebhookChannel,
    build_alert_manager_from_env,
    redact,
)
from aurora.external_monitor import probe_health, run_check
from aurora.failure_tracker import FailureTracker
from aurora.health_monitor import (
    CheckResult,
    HealthCheck,
    HealthMonitor,
    build_default_monitor,
    check_disk_usage,
    check_egress_proxy,
    check_models_available,
    check_stalled_missions,
)
from aurora.orchestration.task_engine import DelegatedTask
from aurora.orchestration.task_store import DurableTaskStore


class Recorder:
    name = "recorder"

    def __init__(self):
        self.messages = []

    def send(self, message):
        self.messages.append(message)


class Exploding:
    name = "exploding"

    def send(self, message):
        raise RuntimeError("network down bot123:SECRET_TOKEN")


def make_manager(*channels, clock=None, dedup=100.0):
    state = {"now": 0.0}
    manager = AlertManager(
        list(channels), dedup_seconds=dedup, clock=clock or (lambda: state["now"]), asynchronous=False, host="srv"
    )
    manager.state = state
    return manager


# -- AlertManager --------------------------------------------------------

def test_dedup_window_and_resolve_only_when_active():
    recorder = Recorder()
    manager = make_manager(recorder)
    assert manager.resolve("k", "recuperado") is False  # nada activo
    assert manager.notify("k", "critical", "caida", "detalle") is True
    assert manager.notify("k", "critical", "caida", "detalle") is False  # dentro de la ventana
    manager.state["now"] = 101.0
    assert manager.notify("k", "critical", "caida") is True  # ventana vencida
    assert manager.resolve("k", "ok") is True
    assert [m.severity for m in recorder.messages] == ["critical", "critical", "recovered"]
    assert recorder.messages[0].text().startswith("🔴 Aurora [srv] caida")


def test_failing_channel_does_not_break_others_or_leak_secrets(caplog):
    recorder = Recorder()
    manager = make_manager(Exploding(), recorder)
    manager.notify("k", "critical", "t")
    assert len(recorder.messages) == 1
    assert "SECRET_TOKEN" not in caplog.text
    assert "bot123:SECRET_TOKEN" not in redact("x bot123:SECRET_TOKEN y")


def test_async_delivery_via_worker_thread():
    recorder = Recorder()
    manager = AlertManager([recorder], asynchronous=True, host="srv")
    manager.notify("k", "warning", "t")
    manager.flush(3.0)
    assert len(recorder.messages) == 1


def test_failure_tracker_integration_alerts_and_recovers():
    recorder = Recorder()
    manager = make_manager(recorder)
    tracker = FailureTracker(alert_threshold=2, alert_sink=manager.from_tracker)
    tracker.record_failure("model_catalog_refresh", RuntimeError("down"))
    assert recorder.messages == []
    tracker.record_failure("model_catalog_refresh", RuntimeError("down"))
    assert len(recorder.messages) == 1 and recorder.messages[0].severity == "critical"
    tracker.record_success("model_catalog_refresh")
    assert recorder.messages[-1].severity == "recovered"


# -- canales y entorno ---------------------------------------------------

def test_telegram_channel_payload_and_webhook_validation():
    posted = []
    poster = SimpleNamespace(post_json=lambda url, payload: posted.append((url, payload)))
    TelegramChannel("123:ABC", "42", poster).send(AlertMessage("k", "critical", "t", "d", "srv"))
    url, payload = posted[0]
    assert url == "https://api.telegram.org/bot123:ABC/sendMessage"
    assert payload["chat_id"] == "42" and "123:ABC" not in payload["text"]
    with pytest.raises(ValueError):
        WebhookChannel("http://example.com/hook", poster)
    WebhookChannel("https://example.com/hook", poster)
    WebhookChannel("http://127.0.0.1:9/hook", poster)


def test_build_from_env_channels_and_proxy():
    env = {
        "AURORA_TELEGRAM_BOT_TOKEN": "1:A",
        "AURORA_TELEGRAM_CHAT_ID": "9",
        "AURORA_ALERT_WEBHOOK_URL": "https://example.com/h",
        "AURORA_EGRESS_PROXY_HOST": "127.0.0.1",
        "AURORA_EGRESS_PROXY_PORT": "3128",
        "AURORA_ALERT_DEDUP_SECONDS": "60",
    }
    manager = build_alert_manager_from_env(env)
    assert [c.name for c in manager.channels] == ["telegram", "webhook"]
    assert manager.dedup_seconds == 60.0
    assert build_alert_manager_from_env({}).channels == []


def test_http_poster_really_posts_json_to_local_webhook():
    received = []

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            received.append(json.loads(self.rfile.read(int(self.headers["Content-Length"]))))
            self.send_response(200)
            self.end_headers()

        def log_message(self, *args):
            pass

    server = HTTPServer(("127.0.0.1", 0), Handler)
    Thread(target=server.serve_forever, daemon=True).start()
    try:
        manager = make_manager(WebhookChannel(f"http://127.0.0.1:{server.server_port}/hook", HttpPoster()))
        manager.notify("k", "critical", "prueba", "detalle")
    finally:
        server.shutdown()
    assert received and received[0]["title"] == "prueba" and "prueba" in received[0]["text"]


# -- HealthMonitor y chequeos --------------------------------------------

def test_monitor_alerts_after_consecutive_failures_and_recovers():
    recorder = Recorder()
    manager = make_manager(recorder)
    state = {"ok": False}
    check = HealthCheck("disk", "Disco casi lleno", lambda: CheckResult(state["ok"], "95% usado", "warning"))
    monitor = HealthMonitor([check], manager, failures_before_alert=2)
    monitor.run_once()
    assert recorder.messages == []  # un solo fallo no alerta
    monitor.run_once()
    assert len(recorder.messages) == 1 and recorder.messages[0].severity == "warning"
    monitor.run_once()
    assert len(recorder.messages) == 1  # deduplicada
    state["ok"] = True
    monitor.run_once()
    assert recorder.messages[-1].severity == "recovered"


def test_crashing_check_is_reported_not_raised():
    recorder = Recorder()
    manager = make_manager(recorder)

    def boom():
        raise RuntimeError("db locked")

    HealthMonitor([HealthCheck("x", "X", boom)], manager, failures_before_alert=1).run_once()
    assert "db locked" in recorder.messages[0].detail


def test_disk_and_proxy_checks(tmp_path):
    assert check_disk_usage(tmp_path, 100.1).ok is True
    assert check_disk_usage(tmp_path, 0.0).ok is False
    listener = socket.socket()
    listener.bind(("127.0.0.1", 0))
    listener.listen(1)
    port = listener.getsockname()[1]
    try:
        assert check_egress_proxy("127.0.0.1", port).ok is True
    finally:
        listener.close()
    assert check_egress_proxy("127.0.0.1", port, timeout=0.5).ok is False


def test_stalled_missions_detected_from_durable_store(tmp_path):
    store = DurableTaskStore(tmp_path / "tasks.db")
    store.enqueue("m-stuck", [DelegatedTask("a", "agent", "work")])
    assert store.stalled_missions(idle_seconds=60) == ()  # recien creada
    future = datetime.now(timezone.utc) + timedelta(hours=1)
    stalled = store.stalled_missions(idle_seconds=1800, now=future)
    assert [m["mission_id"] for m in stalled] == ["m-stuck"] and stalled[0]["pending"] == 1
    result = check_stalled_missions(store, 1800)
    assert result.ok is True  # ahora mismo no esta atascada
    with pytest.raises(Exception):
        store.stalled_missions(idle_seconds=0)


def _snap(routable, code=None):
    return SimpleNamespace(routable=routable, last_error_code=code, last_error_type=None)


def test_models_available_check_levels():
    models = [("nvidia_api", "a"), ("nvidia_api", "b"), ("nvidia_api", "c")]
    store = SimpleNamespace(snapshot=lambda p, m: {"a": _snap(True), "b": _snap(True), "c": _snap(True)}[m])
    assert check_models_available(store, lambda: models).ok is True
    store = SimpleNamespace(snapshot=lambda p, m: _snap(m == "a", "403"))
    degraded = check_models_available(store, lambda: models)
    assert degraded.ok is False and degraded.severity == "warning" and "403 x2" in degraded.detail
    store = SimpleNamespace(snapshot=lambda p, m: _snap(False, "429"))
    down = check_models_available(store, lambda: models)
    assert down.ok is False and down.severity == "critical" and "NINGUN" in down.detail
    assert check_models_available(store, lambda: []).ok is False


def test_default_monitor_builds_expected_checks(tmp_path):
    policy = tmp_path / "policy.json"
    policy.write_text(json.dumps({"models": [{"id": "m1", "provider": "nvidia_api", "enabled": True}]}))
    store = DurableTaskStore(tmp_path / "tasks.db")
    monitor = build_default_monitor(
        store=store, alerts=make_manager(), workspace_root=tmp_path, inference_policy_path=policy,
        proxy_host="127.0.0.1", proxy_port=1, env={},
    )
    assert [c.key for c in monitor.checks] == ["disk", "stalled_missions", "egress_proxy", "models"]
    assert monitor.run_once()["models"].ok is True


# -- monitor externo -----------------------------------------------------

def test_external_monitor_alerts_once_then_recovers_and_persists_state(tmp_path):
    recorder = Recorder()
    manager = make_manager(recorder)
    state_file = tmp_path / "state.json"
    outcome = {"ok": False}
    clock = {"t": 1000.0}

    def run():
        return run_check(
            probe=lambda: (outcome["ok"], "HTTP 500" if not outcome["ok"] else "ok"),
            alerts=manager, state_path=state_file, failures_before_alert=2,
            realert_seconds=3600, now=lambda: clock["t"],
        )

    run()
    assert recorder.messages == []  # primera comprobacion fallida: aun no
    run()
    assert len(recorder.messages) == 1 and "NO responde" in recorder.messages[0].title
    clock["t"] += 600
    run()
    assert len(recorder.messages) == 1  # no repite antes de realert_seconds
    clock["t"] += 4000
    run()
    assert len(recorder.messages) == 2  # re-alerta si sigue caido
    outcome["ok"] = True
    run()
    assert recorder.messages[-1].severity == "recovered"
    assert json.loads(state_file.read_text())["consecutive_failures"] == 0
    run()
    assert len(recorder.messages) == 3  # sin 'recuperado' repetido


def test_probe_health_against_local_server_with_token():
    seen = {}

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            seen["auth"] = self.headers.get("Authorization")
            code = 200 if self.path == "/ok" else 500
            self.send_response(code)
            self.end_headers()
            self.wfile.write(b'{"status": "ok"}')

        def log_message(self, *args):
            pass

    server = HTTPServer(("127.0.0.1", 0), Handler)
    Thread(target=server.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{server.server_port}"
    try:
        assert probe_health(base + "/ok", "tok") == (True, "ok")
        assert seen["auth"] == "Bearer tok"
        assert probe_health(base + "/fail", None) == (False, "HTTP 500")
    finally:
        server.shutdown()
    ok, detail = probe_health(base + "/ok", None, timeout=1.0)
    assert ok is False  # servidor apagado -> detectado
