"""Tarea 2 (Fase 1): los fallos tragados a proposito ya no desaparecen sin rastro."""
import json
import logging
from pathlib import Path
from threading import Thread
from types import SimpleNamespace
from urllib.error import HTTPError
from urllib.request import urlopen

import pytest

from aurora.dashboard.http_server import create_dashboard_server
from aurora.failure_tracker import FailureTracker, set_tracker
from aurora.orchestration.director_runtime import DirectorRuntime

UI_ROOT = Path(__file__).parents[1] / "aurora" / "dashboard" / "ui"


@pytest.fixture
def tracker():
    alerts = []
    clock = {"now": 0.0}
    instance = FailureTracker(
        alert_threshold=3,
        alert_cooldown_seconds=100.0,
        alert_sink=alerts.append,
        monotonic=lambda: clock["now"],
    )
    instance.alerts = alerts
    instance.clock = clock
    previous = set_tracker(instance)
    yield instance
    set_tracker(previous)


def test_counts_consecutive_failures_and_alerts_once_at_threshold(tracker, caplog):
    caplog.set_level(logging.WARNING, logger="aurora.health")
    for _ in range(2):
        tracker.record_failure("model_catalog_refresh", RuntimeError("boom"))
    assert tracker.alerts == []
    tracker.record_failure("model_catalog_refresh", RuntimeError("boom"))
    assert len(tracker.alerts) == 1
    assert tracker.alerts[0]["kind"] == "failure_threshold"
    assert tracker.alerts[0]["consecutive_failures"] == 3
    # un cuarto fallo dentro del enfriamiento no repite la alerta
    tracker.record_failure("model_catalog_refresh", RuntimeError("boom"))
    assert len(tracker.alerts) == 1
    assert tracker.degraded_components() == ["model_catalog_refresh"]
    assert "swallowed failure in model_catalog_refresh" in caplog.text


def test_alert_repeats_after_cooldown_and_recovery_is_reported(tracker):
    for _ in range(3):
        tracker.record_failure("x", ValueError("a"))
    tracker.clock["now"] = 101.0
    tracker.record_failure("x", ValueError("a"))
    assert [a["kind"] for a in tracker.alerts] == ["failure_threshold", "failure_threshold"]
    tracker.record_success("x")
    assert tracker.alerts[-1]["kind"] == "recovered"
    assert tracker.snapshot()["x"]["consecutive_failures"] == 0
    assert tracker.snapshot()["x"]["total_failures"] == 4
    assert tracker.degraded_components() == []


def test_secrets_are_redacted_and_errors_truncated(tracker):
    tracker.record_failure("x", RuntimeError("401 Bearer abc.DEF-123 and nvapi-SECRETKEY999 " + "z" * 1000))
    text = tracker.snapshot()["x"]["last_error"]
    assert "abc.DEF-123" not in text and "SECRETKEY999" not in text
    assert "***" in text and len(text) <= 300


def test_failing_alert_sink_never_breaks_the_runtime():
    def bad_sink(_payload):
        raise RuntimeError("telegram down")

    local = FailureTracker(alert_threshold=1, alert_sink=bad_sink)
    assert local.record_failure("x", RuntimeError("e")) == 1


def _runtime_stub(discovery):
    return SimpleNamespace(
        model_discovery_refresh_enabled=True,
        model_discovery=discovery,
        autonomous_discovery_refresh=None,
        _last_model_discovery_refresh_at=None,
        model_discovery_refresh_interval_seconds=900.0,
    )


def test_catalog_refresh_failures_are_counted_then_recover(tracker):
    class Discovery:
        fail = True

        def refresh_all(self, **_kwargs):
            if self.fail:
                raise RuntimeError("catalog unreachable")

        def activate_free_discovered(self, **_kwargs):
            return None

    discovery = Discovery()
    stub = _runtime_stub(discovery)
    for _ in range(3):
        stub._last_model_discovery_refresh_at = None  # saltar el intervalo
        DirectorRuntime._refresh_model_catalogs_if_due(stub)  # no debe propagar
    assert tracker.snapshot()["model_catalog_refresh"]["consecutive_failures"] == 3
    assert len(tracker.alerts) == 1
    discovery.fail = False
    stub._last_model_discovery_refresh_at = None
    DirectorRuntime._refresh_model_catalogs_if_due(stub)
    assert tracker.snapshot()["model_catalog_refresh"]["consecutive_failures"] == 0
    assert tracker.alerts[-1]["kind"] == "recovered"


def _serve(health_service):
    server = create_dashboard_server(
        dashboard_gateway=SimpleNamespace(snapshot=lambda **_: {}),
        conversation_api=object(),
        health_service=health_service,
        host="127.0.0.1",
        port=0,
        ui_root=UI_ROOT,
    )
    Thread(target=server.serve_forever, daemon=True).start()
    return server, "http://127.0.0.1:" + str(server.server_address[1])


def test_health_endpoint_exposes_runtime_failures(tracker):
    tracker.record_failure("observability_record", RuntimeError("disk full"))
    server, base = _serve(SimpleNamespace(health=lambda: {"status": "ok"}))
    try:
        with urlopen(base + "/api/dashboard/health", timeout=5) as response:
            data = json.loads(response.read().decode("utf-8"))
        assert data["status"] == "ok"
        assert data["runtime_failures"]["observability_record"]["consecutive_failures"] == 1
    finally:
        server.shutdown()


def test_internal_dashboard_errors_are_logged_server_side(tracker, caplog):
    def broken():
        raise RuntimeError("secret internals")

    caplog.set_level(logging.ERROR, logger="aurora.dashboard")
    server, base = _serve(SimpleNamespace(health=broken))
    try:
        with pytest.raises(HTTPError) as caught:
            urlopen(base + "/api/dashboard/health", timeout=5)
        assert caught.value.code == 500
        body = caught.value.read().decode("utf-8")
        assert "secret internals" not in body  # el cliente sigue sin ver detalles
    finally:
        server.shutdown()
    assert "dashboard request failed" in caplog.text
    assert "secret internals" in caplog.text  # pero el operador si los ve en el log
