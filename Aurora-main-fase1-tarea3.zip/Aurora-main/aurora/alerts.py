"""Alertas salientes (Telegram / webhook) con deduplicacion y envio asincrono.

Diseno:
  * ``AlertManager.notify`` deduplica por clave (una alerta por clave y ventana).
  * ``AlertManager.resolve`` envia "recuperado" solo si esa clave estaba activa.
  * El envio va en un hilo aparte: una red caida nunca bloquea el runtime.
  * Los fallos del canal se registran en el log (con secretos ocultos) y nunca se propagan.
  * ``AlertManager.from_tracker`` es el ``alert_sink`` de ``FailureTracker``.
"""
from __future__ import annotations

import json
import logging
import os
import queue
import re
import socket
import threading
import time
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Protocol
from urllib.parse import urlparse

logger = logging.getLogger("aurora.alerts")

_SECRET = re.compile(r"(bot\d+:[A-Za-z0-9_\-]+|nvapi-[A-Za-z0-9._\-]+|Bearer\s+[A-Za-z0-9._\-]+)", re.IGNORECASE)
_ICONS = {"critical": "🔴", "warning": "🟠", "recovered": "🟢"}


def redact(text: str) -> str:
    return _SECRET.sub("***", text)


@dataclass(frozen=True)
class AlertMessage:
    key: str
    severity: str  # critical | warning | recovered
    title: str
    detail: str
    host: str

    def text(self) -> str:
        icon = _ICONS.get(self.severity, "")
        body = f"{icon} Aurora [{self.host}] {self.title}"
        return body + (f"\n{self.detail}" if self.detail else "")


class AlertChannel(Protocol):
    name: str

    def send(self, message: AlertMessage) -> None: ...


class HttpPoster:
    """POST JSON con urllib; opcionalmente a traves del proxy de salida gobernado."""

    def __init__(self, proxy_url: str | None = None, timeout: float = 10.0) -> None:
        handler = urllib.request.ProxyHandler({"https": proxy_url, "http": proxy_url} if proxy_url else {})
        self._opener = urllib.request.build_opener(handler)
        self.timeout = timeout

    def post_json(self, url: str, payload: Mapping[str, Any]) -> None:
        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with self._opener.open(request, timeout=self.timeout) as response:
            if not 200 <= response.status < 300:
                raise RuntimeError(f"alert endpoint returned HTTP {response.status}")


class TelegramChannel:
    name = "telegram"

    def __init__(self, bot_token: str, chat_id: str, poster: Any) -> None:
        self._url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        self._chat_id = chat_id
        self._poster = poster

    def send(self, message: AlertMessage) -> None:
        self._poster.post_json(
            self._url,
            {"chat_id": self._chat_id, "text": message.text(), "disable_web_page_preview": True},
        )


class WebhookChannel:
    """Webhook generico. Incluye ``text`` (Slack) y ``content`` (Discord)."""

    name = "webhook"

    def __init__(self, url: str, poster: Any) -> None:
        parsed = urlparse(url)
        local = parsed.hostname in {"127.0.0.1", "localhost", "::1"}
        if parsed.scheme != "https" and not (parsed.scheme == "http" and local):
            raise ValueError("AURORA_ALERT_WEBHOOK_URL must use https")
        self._url = url
        self._poster = poster

    def send(self, message: AlertMessage) -> None:
        text = message.text()
        self._poster.post_json(
            self._url,
            {"text": text, "content": text, "key": message.key, "severity": message.severity, "title": message.title},
        )


class AlertManager:
    def __init__(
        self,
        channels: list[AlertChannel] | None = None,
        *,
        dedup_seconds: float = 1800.0,
        clock: Callable[[], float] = time.monotonic,
        asynchronous: bool = True,
        host: str | None = None,
        queue_size: int = 100,
    ) -> None:
        self.channels = list(channels or [])
        self.dedup_seconds = dedup_seconds
        self._clock = clock
        self._asynchronous = asynchronous
        self._host = host or socket.gethostname()
        self._lock = threading.Lock()
        self._last_sent: dict[str, float] = {}
        self._queue: queue.Queue[AlertMessage] = queue.Queue(maxsize=queue_size)
        self._worker: threading.Thread | None = None

    # -- API publica ------------------------------------------------------
    def notify(self, key: str, severity: str, title: str, detail: str = "", *, force: bool = False) -> bool:
        """Envia una alerta salvo que la misma clave ya se enviara dentro de la ventana."""
        now = self._clock()
        with self._lock:
            last = self._last_sent.get(key)
            if last is not None and now - last < self.dedup_seconds and not force:
                return False
            self._last_sent[key] = now
        self._dispatch(AlertMessage(key, severity, title, detail, self._host))
        return True

    def resolve(self, key: str, title: str, detail: str = "", *, force: bool = False) -> bool:
        """Envia 'recuperado' solo si la clave estaba activa (o con force=True)."""
        with self._lock:
            if key not in self._last_sent and not force:
                return False
            self._last_sent.pop(key, None)
        self._dispatch(AlertMessage(key, "recovered", title, detail, self._host))
        return True

    def from_tracker(self, payload: Mapping[str, Any]) -> None:
        """``alert_sink`` para FailureTracker."""
        component = str(payload.get("component", "?"))
        key = f"tracker:{component}"
        if payload.get("kind") == "recovered":
            self.resolve(key, f"{component} recuperado", f"tras {payload.get('previous_consecutive_failures')} fallos seguidos")
            return
        self.notify(
            key,
            "critical",
            f"{component} falla repetidamente ({payload.get('consecutive_failures')} seguidos)",
            str(payload.get("last_error", "")),
        )

    def flush(self, timeout: float = 5.0) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self._queue.unfinished_tasks == 0:
                return
            time.sleep(0.02)

    # -- interno ----------------------------------------------------------
    def _dispatch(self, message: AlertMessage) -> None:
        log = logger.error if message.severity == "critical" else logger.warning
        log("ALERT [%s] %s | %s", message.severity, message.title, redact(message.detail)[:300])
        if not self.channels:
            return
        if not self._asynchronous:
            self._deliver(message)
            return
        self._ensure_worker()
        try:
            self._queue.put_nowait(message)
        except queue.Full:
            logger.warning("alert queue full; dropping %s", message.key)

    def _ensure_worker(self) -> None:
        with self._lock:
            if self._worker is None or not self._worker.is_alive():
                self._worker = threading.Thread(target=self._run, name="aurora-alerts", daemon=True)
                self._worker.start()

    def _run(self) -> None:
        while True:
            message = self._queue.get()
            try:
                self._deliver(message)
            finally:
                self._queue.task_done()

    def _deliver(self, message: AlertMessage) -> None:
        for channel in self.channels:
            try:
                channel.send(message)
            except Exception as exc:  # un canal caido no debe afectar a los demas
                logger.error("alert channel %s failed: %s", channel.name, redact(f"{type(exc).__name__}: {exc}")[:200])


def build_alert_manager_from_env(
    env: Mapping[str, str] | None = None,
    *,
    use_egress_proxy: bool | None = None,
    asynchronous: bool = True,
) -> AlertManager:
    """Construye el AlertManager desde variables de entorno.

    AURORA_TELEGRAM_BOT_TOKEN + AURORA_TELEGRAM_CHAT_ID, y/o AURORA_ALERT_WEBHOOK_URL.
    AURORA_ALERT_DEDUP_SECONDS (def. 1800). AURORA_ALERT_USE_EGRESS_PROXY (def. 1).
    """
    env = os.environ if env is None else env
    if use_egress_proxy is None:
        use_egress_proxy = env.get("AURORA_ALERT_USE_EGRESS_PROXY", "1").strip().lower() not in {"0", "false", "no"}
    proxy_url = None
    proxy_host = env.get("AURORA_EGRESS_PROXY_HOST", "").strip()
    if use_egress_proxy and proxy_host:
        proxy_url = f"http://{proxy_host}:{env.get('AURORA_EGRESS_PROXY_PORT', '3128').strip() or '3128'}"
    poster = HttpPoster(proxy_url)
    channels: list[AlertChannel] = []
    token = env.get("AURORA_TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = env.get("AURORA_TELEGRAM_CHAT_ID", "").strip()
    if token and chat_id:
        channels.append(TelegramChannel(token, chat_id, poster))
    webhook = env.get("AURORA_ALERT_WEBHOOK_URL", "").strip()
    if webhook:
        channels.append(WebhookChannel(webhook, poster))
    if not channels:
        logger.warning("no alert channel configured (set AURORA_TELEGRAM_BOT_TOKEN/CHAT_ID or AURORA_ALERT_WEBHOOK_URL); alerts go to the log only")
    try:
        dedup = float(env.get("AURORA_ALERT_DEDUP_SECONDS", "").strip() or 1800)
    except ValueError:
        dedup = 1800.0
    return AlertManager(channels, dedup_seconds=dedup, asynchronous=asynchronous)
