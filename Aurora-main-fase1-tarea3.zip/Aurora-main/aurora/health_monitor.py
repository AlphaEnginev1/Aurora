"""Chequeos periodicos de salud del runtime 24/7 con alertas.

Cada chequeo devuelve ``CheckResult``. Un chequeo debe fallar ``failures_before_alert``
ciclos seguidos antes de alertar (evita falsas alarmas por picos) y avisa al recuperarse.
"""
from __future__ import annotations

import json
import logging
import shutil
import socket
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Sequence

logger = logging.getLogger("aurora.health_monitor")


@dataclass(frozen=True)
class CheckResult:
    ok: bool
    detail: str = ""
    severity: str = "critical"  # critical | warning


@dataclass(frozen=True)
class HealthCheck:
    key: str
    title: str
    run: Callable[[], CheckResult]


class HealthMonitor:
    def __init__(
        self,
        checks: Sequence[HealthCheck],
        alerts: Any,
        *,
        interval_seconds: float = 60.0,
        failures_before_alert: int = 2,
    ) -> None:
        self.checks = list(checks)
        self.alerts = alerts
        self.interval_seconds = interval_seconds
        self.failures_before_alert = max(1, failures_before_alert)
        self._consecutive: dict[str, int] = {}
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def run_once(self) -> dict[str, CheckResult]:
        results: dict[str, CheckResult] = {}
        for check in self.checks:
            try:
                result = check.run()
            except Exception as exc:  # un chequeo roto es en si un problema que alertar
                result = CheckResult(False, f"el chequeo fallo: {type(exc).__name__}: {str(exc)[:150]}", "warning")
            results[check.key] = result
            if result.ok:
                if self._consecutive.get(check.key, 0) >= self.failures_before_alert:
                    self.alerts.resolve(f"health:{check.key}", f"{check.title}: recuperado", result.detail)
                self._consecutive[check.key] = 0
                continue
            count = self._consecutive.get(check.key, 0) + 1
            self._consecutive[check.key] = count
            if count >= self.failures_before_alert:
                self.alerts.notify(f"health:{check.key}", result.severity, check.title, result.detail)
        return results

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="aurora-health-monitor", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 5.0) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout)

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.run_once()
            except Exception:
                logger.exception("health monitor cycle failed")
            self._stop.wait(self.interval_seconds)


# -- chequeos concretos ----------------------------------------------------

def check_disk_usage(path: str | Path, threshold_percent: float = 80.0) -> CheckResult:
    usage = shutil.disk_usage(str(path))
    percent = usage.used / usage.total * 100.0
    free_gb = usage.free / 1024**3
    detail = f"{path}: {percent:.0f}% usado, {free_gb:.1f} GB libres"
    return CheckResult(percent < threshold_percent, detail, "critical" if percent >= 95 else "warning")


def check_egress_proxy(host: str, port: int, timeout: float = 3.0) -> CheckResult:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return CheckResult(True, f"{host}:{port} responde")
    except OSError as exc:
        return CheckResult(False, f"proxy de salida {host}:{port} inaccesible ({type(exc).__name__})")


def check_stalled_missions(store: Any, idle_seconds: float) -> CheckResult:
    stalled = store.stalled_missions(idle_seconds=idle_seconds)
    if not stalled:
        return CheckResult(True, "sin misiones atascadas")
    lines = [
        f"{item['mission_id']}: {int(item['idle_seconds'] // 60)} min sin actividad "
        f"({item['running']} en curso, {item['pending']} pendientes)"
        for item in stalled[:5]
    ]
    extra = f" (+{len(stalled) - 5} mas)" if len(stalled) > 5 else ""
    return CheckResult(False, "; ".join(lines) + extra, "warning")


def enabled_models_from_policy(policy_path: str | Path) -> list[tuple[str, str]]:
    policy = json.loads(Path(policy_path).read_text(encoding="utf-8"))
    return [
        (str(model.get("provider", "nvidia_api")), str(model["id"]))
        for model in policy.get("models", [])
        if model.get("enabled") is True
    ]


def check_models_available(
    health_store: Any,
    enabled_models: Callable[[], Sequence[tuple[str, str]]],
    degraded_fraction: float = 0.5,
) -> CheckResult:
    """Critico si ningun modelo habilitado es enrutable; aviso si falla una fraccion alta."""
    models = list(enabled_models())
    if not models:
        return CheckResult(False, "no hay ningun modelo habilitado en la politica de inferencia")
    blocked: list[Any] = []
    for provider_id, model_id in models:
        snapshot = health_store.snapshot(provider_id, model_id)
        if not snapshot.routable:
            blocked.append(snapshot)
    ok_count = len(models) - len(blocked)
    codes: dict[str, int] = {}
    for snapshot in blocked:
        code = str(snapshot.last_error_code or snapshot.last_error_type or "?")
        codes[code] = codes.get(code, 0) + 1
    summary = ", ".join(f"{code} x{n}" for code, n in sorted(codes.items()))
    detail = f"{ok_count}/{len(models)} modelos operativos" + (f"; errores: {summary}" if summary else "")
    if ok_count == 0:
        return CheckResult(False, "NINGUN modelo disponible. " + detail, "critical")
    if len(blocked) / len(models) >= degraded_fraction:
        return CheckResult(False, "muchos modelos caidos. " + detail, "warning")
    return CheckResult(True, detail)


def build_default_monitor(
    *,
    store: Any,
    alerts: Any,
    workspace_root: str | Path,
    inference_policy_path: str | Path,
    proxy_host: str | None,
    proxy_port: int,
    env: Any = None,
) -> HealthMonitor:
    """Monitor estandar del daemon: disco, proxy de salida, misiones atascadas y modelos."""
    import os

    env = os.environ if env is None else env
    interval = float(env.get("AURORA_MONITOR_INTERVAL_SECONDS", "") or 60)
    disk_percent = float(env.get("AURORA_DISK_ALERT_PERCENT", "") or 80)
    stalled_seconds = float(env.get("AURORA_STALLED_MISSION_MINUTES", "") or 30) * 60.0
    workspace = Path(workspace_root)

    checks = [
        HealthCheck("disk", "Disco casi lleno", lambda: check_disk_usage(workspace, disk_percent)),
        HealthCheck("stalled_missions", "Misiones atascadas", lambda: check_stalled_missions(store, stalled_seconds)),
    ]
    if proxy_host:
        checks.append(
            HealthCheck("egress_proxy", "Proxy de salida inaccesible", lambda: check_egress_proxy(proxy_host, proxy_port))
        )
    try:
        from aurora.inference.provider_health import ProviderHealthStore

        health_store = ProviderHealthStore(workspace / "tasks.db")
        checks.append(
            HealthCheck(
                "models",
                "Modelos de inferencia no disponibles",
                lambda: check_models_available(health_store, lambda: enabled_models_from_policy(inference_policy_path)),
            )
        )
    except Exception:
        logger.exception("model availability check disabled")
    return HealthMonitor(checks, alerts, interval_seconds=interval)
