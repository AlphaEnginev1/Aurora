"""Visibilidad de fallos tragados a proposito (best-effort) en el runtime 24/7.

Varias rutas de Aurora capturan ``Exception`` a proposito para no tumbar una
mision por un fallo "consultivo" (refresco de catalogos, observabilidad, salud
de proveedores...). Hasta ahora esos fallos desaparecian sin dejar rastro.

Este modulo no cambia el comportamiento: sigue sin propagar. Solo:
  * registra el fallo en el log (journald lo captura desde stderr),
  * cuenta fallos consecutivos por componente,
  * dispara un callback de alerta al superar un umbral (con enfriamiento),
  * expone un resumen para el endpoint de salud.
"""
from __future__ import annotations

import logging
import os
import re
import threading
import time
from typing import Any, Callable, Mapping

logger = logging.getLogger("aurora.health")

_SECRET_PATTERN = re.compile(r"(nvapi-|Bearer\s+|api[_-]?key=)[A-Za-z0-9._\-]+", re.IGNORECASE)
_MAX_ERROR_CHARS = 300

AlertSink = Callable[[Mapping[str, Any]], None]


def _safe_error_text(error: BaseException) -> str:
    text = f"{type(error).__name__}: {error}"
    text = _SECRET_PATTERN.sub(lambda m: m.group(1) + "***", text)
    return text[:_MAX_ERROR_CHARS]


def _env_int(name: str, default: int) -> int:
    try:
        return max(1, int(os.getenv(name, "").strip() or default))
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return max(0.0, float(os.getenv(name, "").strip() or default))
    except ValueError:
        return default


class FailureTracker:
    """Contadores thread-safe de fallos consecutivos por componente."""

    def __init__(
        self,
        *,
        alert_threshold: int | None = None,
        alert_cooldown_seconds: float | None = None,
        alert_sink: AlertSink | None = None,
        monotonic: Callable[[], float] = time.monotonic,
        wall_clock: Callable[[], float] = time.time,
    ) -> None:
        self.alert_threshold = alert_threshold or _env_int("AURORA_FAILURE_ALERT_THRESHOLD", 3)
        self.alert_cooldown_seconds = (
            alert_cooldown_seconds
            if alert_cooldown_seconds is not None
            else _env_float("AURORA_FAILURE_ALERT_COOLDOWN_SECONDS", 900.0)
        )
        self.alert_sink = alert_sink
        self._monotonic = monotonic
        self._wall_clock = wall_clock
        self._lock = threading.Lock()
        self._state: dict[str, dict[str, Any]] = {}

    def record_failure(self, component: str, error: BaseException) -> int:
        """Registra un fallo tragado. Devuelve los fallos consecutivos actuales."""
        text = _safe_error_text(error)
        alert: dict[str, Any] | None = None
        with self._lock:
            state = self._state.setdefault(component, self._new_state())
            state["consecutive_failures"] += 1
            state["total_failures"] += 1
            state["last_error"] = text
            state["last_failure_at"] = self._wall_clock()
            consecutive = state["consecutive_failures"]
            if consecutive >= self.alert_threshold:
                now = self._monotonic()
                last = state["_last_alert_monotonic"]
                if last is None or now - last >= self.alert_cooldown_seconds:
                    state["_last_alert_monotonic"] = now
                    state["alerting"] = True
                    alert = {
                        "kind": "failure_threshold",
                        "component": component,
                        "consecutive_failures": consecutive,
                        "total_failures": state["total_failures"],
                        "last_error": text,
                    }
        logger.warning("swallowed failure in %s (consecutive=%d): %s", component, consecutive, text)
        if alert is not None:
            logger.error(
                "ALERT %s failed %d times in a row: %s",
                component,
                alert["consecutive_failures"],
                text,
            )
            self._send(alert)
        return consecutive

    def record_success(self, component: str) -> None:
        """Marca recuperacion: reinicia el contador y avisa si estaba en alerta."""
        recovered: dict[str, Any] | None = None
        with self._lock:
            state = self._state.setdefault(component, self._new_state())
            was_alerting = state["alerting"]
            previous = state["consecutive_failures"]
            state["consecutive_failures"] = 0
            state["alerting"] = False
            state["_last_alert_monotonic"] = None
            state["last_success_at"] = self._wall_clock()
            if was_alerting:
                recovered = {
                    "kind": "recovered",
                    "component": component,
                    "previous_consecutive_failures": previous,
                }
        if recovered is not None:
            logger.warning("RECOVERED %s after %d consecutive failures", component, recovered["previous_consecutive_failures"])
            self._send(recovered)

    def snapshot(self) -> dict[str, dict[str, Any]]:
        with self._lock:
            return {
                name: {key: value for key, value in state.items() if not key.startswith("_")}
                for name, state in self._state.items()
            }

    def degraded_components(self) -> list[str]:
        with self._lock:
            return sorted(name for name, state in self._state.items() if state["alerting"])

    def _send(self, payload: Mapping[str, Any]) -> None:
        sink = self.alert_sink
        if sink is None:
            return
        try:
            sink(payload)
        except Exception:  # el canal de alertas nunca debe romper el runtime
            logger.exception("alert sink failed for %s", payload.get("component"))

    @staticmethod
    def _new_state() -> dict[str, Any]:
        return {
            "consecutive_failures": 0,
            "total_failures": 0,
            "last_error": None,
            "last_failure_at": None,
            "last_success_at": None,
            "alerting": False,
            "_last_alert_monotonic": None,
        }


_default_tracker = FailureTracker()


def get_tracker() -> FailureTracker:
    return _default_tracker


def set_tracker(tracker: FailureTracker) -> FailureTracker:
    """Sustituye el tracker global (lo usaran las alertas de la tarea 3 y los tests)."""
    global _default_tracker
    previous = _default_tracker
    _default_tracker = tracker
    return previous


def report_failure(component: str, error: BaseException) -> int:
    return _default_tracker.record_failure(component, error)


def report_success(component: str) -> None:
    _default_tracker.record_success(component)


def configure_logging(level: str | None = None) -> None:
    """Configura logging a stderr (journald) una sola vez. Nivel: AURORA_LOG_LEVEL."""
    root = logging.getLogger()
    if any(getattr(handler, "_aurora_handler", False) for handler in root.handlers):
        return
    handler = logging.StreamHandler()
    handler._aurora_handler = True  # type: ignore[attr-defined]
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root.addHandler(handler)
    chosen = (level or os.getenv("AURORA_LOG_LEVEL", "INFO")).strip().upper()
    root.setLevel(getattr(logging, chosen, logging.INFO))
