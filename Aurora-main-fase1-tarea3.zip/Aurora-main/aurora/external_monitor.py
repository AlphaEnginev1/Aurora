"""Monitor externo: comprueba el endpoint de salud y avisa si Aurora no responde.

Pensado para ejecutarse cada minuto desde un timer systemd (deploy/aurora-monitor.timer),
como proceso independiente del daemon, para detectar tambien que el servicio este caido.

    python -m aurora.external_monitor

Variables: AURORA_MONITOR_URL, AURORA_DASHBOARD_API_TOKEN, AURORA_MONITOR_STATE,
AURORA_MONITOR_FAILURES_BEFORE_ALERT (def. 2), AURORA_MONITOR_REALERT_SECONDS (def. 21600),
AURORA_MONITOR_SYSTEMD_UNIT (opcional, p. ej. aurora.service),
AURORA_MONITOR_USE_EGRESS_PROXY (def. 0: el monitor envia directo, porque el proxy puede estar caido).
Canales: los mismos que el daemon (Telegram / webhook).
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable, Mapping

from aurora.alerts import AlertManager, build_alert_manager_from_env

logger = logging.getLogger("aurora.external_monitor")
ALERT_KEY = "external:aurora-down"


def probe_health(url: str, token: str | None, timeout: float = 10.0) -> tuple[bool, str]:
    request = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"} if token else {})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))  # nunca usar proxies del entorno
    try:
        with opener.open(request, timeout=timeout) as response:
            body = response.read(2_000_000)
            if response.status != 200:
                return False, f"HTTP {response.status}"
            json.loads(body.decode("utf-8"))
            return True, "ok"
    except urllib.error.HTTPError as exc:
        return False, f"HTTP {exc.code}"
    except json.JSONDecodeError:
        return False, "respuesta de salud no es JSON valido"
    except Exception as exc:
        return False, f"{type(exc).__name__}: {str(exc)[:120]}"


def probe_systemd_unit(unit: str) -> tuple[bool, str]:
    try:
        result = subprocess.run(["systemctl", "is-active", unit], capture_output=True, text=True, timeout=10)
    except Exception as exc:
        return False, f"no se pudo consultar systemd: {type(exc).__name__}"
    state = result.stdout.strip() or "unknown"
    return state == "active", f"{unit} esta '{state}'"


def run_check(
    *,
    probe: Callable[[], tuple[bool, str]],
    alerts: AlertManager,
    state_path: Path,
    failures_before_alert: int = 2,
    realert_seconds: float = 21600.0,
    now: Callable[[], float] = time.time,
) -> dict[str, Any]:
    """Una ejecucion del monitor. El estado persiste en disco entre ejecuciones."""
    try:
        state = json.loads(state_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        state = {}
    failures = int(state.get("consecutive_failures", 0))
    alerted_at = state.get("alerted_at")
    ok, detail = probe()
    if ok:
        if alerted_at is not None:
            alerts.resolve(ALERT_KEY, "Aurora ha vuelto a responder", f"tras {failures} comprobaciones fallidas", force=True)
        state = {"consecutive_failures": 0, "alerted_at": None}
    else:
        failures += 1
        due = alerted_at is None or now() - float(alerted_at) >= realert_seconds
        if failures >= failures_before_alert and due:
            alerts.notify(ALERT_KEY, "critical", "Aurora NO responde", f"{detail} ({failures} comprobaciones seguidas)", force=True)
            alerted_at = now()
        state = {"consecutive_failures": failures, "alerted_at": alerted_at, "last_detail": detail}
    try:
        state_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = state_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(state), encoding="utf-8")
        tmp.replace(state_path)
    except OSError as exc:
        logger.error("no se pudo guardar el estado del monitor: %s", exc)
    alerts.flush(15.0)
    return {"ok": ok, "detail": detail, **state}


def main(env: Mapping[str, str] | None = None) -> int:
    env = os.environ if env is None else env
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    port = env.get("AURORA_DASHBOARD_PORT", "8787")
    url = env.get("AURORA_MONITOR_URL", f"http://127.0.0.1:{port}/api/dashboard/health")
    token = env.get("AURORA_DASHBOARD_API_TOKEN") or None
    unit = env.get("AURORA_MONITOR_SYSTEMD_UNIT", "").strip()
    use_proxy = env.get("AURORA_MONITOR_USE_EGRESS_PROXY", "0").strip().lower() in {"1", "true", "yes"}
    alerts = build_alert_manager_from_env(env, use_egress_proxy=use_proxy, asynchronous=False)

    def probe() -> tuple[bool, str]:
        if unit:
            ok, detail = probe_systemd_unit(unit)
            if not ok:
                return False, detail
        return probe_health(url, token)

    workspace = env.get("AURORA_WORKSPACE_ROOT", ".aurora-runtime")
    result = run_check(
        probe=probe,
        alerts=alerts,
        state_path=Path(env.get("AURORA_MONITOR_STATE", f"{workspace}/monitor-state.json")),
        failures_before_alert=max(1, int(env.get("AURORA_MONITOR_FAILURES_BEFORE_ALERT", "2") or 2)),
        realert_seconds=float(env.get("AURORA_MONITOR_REALERT_SECONDS", "21600") or 21600),
    )
    logger.info("monitor: ok=%s detail=%s failures=%s", result["ok"], result["detail"], result.get("consecutive_failures"))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
